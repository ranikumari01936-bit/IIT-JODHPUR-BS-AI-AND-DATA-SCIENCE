#!/usr/bin/env bash
# Inspect CPU, memory, OS/kernel, USB and PCI devices.
# Run from the directory where you want the output files created.

lscpu > cpu_info.txt
free -h > system_mem.txt
{
  echo "Kernel version:"
  uname -r
  echo
  echo "Architecture:"
  uname -m
  echo
  echo "OS release:"
  cat /etc/os-release
} > os_details.txt
{
  echo "USB devices:"
  lsusb 2>&1
  echo
  echo "PCI devices:"
  lspci 2>&1
} > hardware_summary.txt
