#!/usr/bin/env bash
# File filtering and output redirection demonstration.
# Run from the directory where you want the output files created.

# List /etc entries, pass through a filter, and keep only .conf paths.
find /etc -type f -name '*.conf' 2>/dev/null | sort > config_search.txt

# Filter process table for Python processes; omit grep itself.
ps aux | grep -i '[p]ython' > process_log.txt

# Demonstrate append redirection: add a timestamped /etc directory listing.
{
  echo "Directory listing appended at: $(date)"
  ls -la /etc
  echo
} >> directory_listing.log

# Capture both standard output and standard error in one report.
ls /etc /this_path_does_not_exist_for_redirection_test > redirection_test.txt 2>&1
