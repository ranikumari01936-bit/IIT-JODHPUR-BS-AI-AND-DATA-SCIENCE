#!/bin/bash
# access_test.sh - runs each operation as each role and logs SUCCESS / DENIED
BASE=/tmp/dir_lab; LOG="${1:-access_test.log}"
run(){ # role uid gid desc cmd
  local out; out=$(setpriv --reuid=$2 --regid=$3 --groups $3 bash -c "cd $BASE && $5" 2>&1)
  if [ $? -eq 0 ]; then r=SUCCESS; else r="DENIED ($(echo "$out"|sed 's/^.*: //'))"; fi
  printf '%-8s | %-42s | %s\n' "$1" "$4" "$r" >> "$LOG"
}
echo "ACCESS TEST LOG  -  $(date '+%F %T')" > "$LOG"
echo "Roles: owner=uid1001  student=uid1002 (group students 2000)  other=uid1003" >> "$LOG"
echo "Perms: shared_lab mode 2710 = drwx--s--- (owner rwx, group --x + setgid, others none)" >> "$LOG"
echo "------------------------------------------------------------------------------" >> "$LOG"
for role in "owner 1001 2000" "student 1002 2000" "other 1003 1003"; do set -- $role; R=$1; U=$2; GG=$3
 ./directory_setup.sh $BASE
 echo "[$R]" >> "$LOG"
 run $R $U $GG "READ    list shared_lab (ls)"              "ls shared_lab"
 run $R $U $GG "EXECUTE traverse shared_lab (cd)"          "cd shared_lab"
 run $R $U $GG "EXECUTE open known file in shared_lab"     "cat shared_lab/handout.txt"
 run $R $U $GG "EXECUTE enter shared_lab/sub"              "cd shared_lab/sub && cat data.txt"
 run $R $U $GG "WRITE   create file in shared_lab"         "touch shared_lab/new.txt"
 run $R $U $GG "WRITE   rename handout.txt"                "mv shared_lab/handout.txt shared_lab/renamed.txt"
 run $R $U $GG "WRITE   delete handout.txt"                "rm \$( [ -e shared_lab/handout.txt ] && echo shared_lab/handout.txt || echo shared_lab/renamed.txt )"
 run $R $U $GG "READ    list project_data"                 "ls project_data"
 run $R $U $GG "READ    read report.txt"                   "cat report.txt"
 run $R $U $GG "WRITE   write report.txt"                  "echo x >> report.txt"
 run $R $U $GG "EXECUTE run script.sh"                     "./script.sh"
done
