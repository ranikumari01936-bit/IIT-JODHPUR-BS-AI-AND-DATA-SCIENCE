#!/bin/bash
# directory_setup.sh - Directory access controls (run as root; uses numeric IDs, no useradd needed)
# Roles: owner uid=1001 | student uid=1002 (group 2000 'students') | other uid=1003 (public)
BASE="${1:-/tmp/dir_lab}"; OWNER=1001; GRP=2000
rm -rf "$BASE"; mkdir -p "$BASE" && cd "$BASE" || exit 1

# project_data: owner full access only (rwx------ = 700)
mkdir project_data && chmod 700 project_data
echo "project secrets" > project_data/notes.txt && chmod 600 project_data/notes.txt

# report.txt: owner rw, group read, public none (rw-r----- = 640)
echo "Quarterly report" > report.txt && chmod 640 report.txt

# script.sh: no access for public (rwxr-x--- = 750)
printf '#!/bin/bash\necho hello\n' > script.sh && chmod 750 script.sh

# shared_lab: students may TRAVERSE only (--x for group). Owner rwx, group --x, others none = 710
# setgid (2710) makes new sub-directories inherit group 'students'.
mkdir shared_lab
echo "lab handout" > shared_lab/handout.txt && chmod 640 shared_lab/handout.txt   # group can't list, but file perms still matter
chmod 644 shared_lab/handout.txt                       # readable if the name is known
chmod 2710 shared_lab

# sub-directory: created inside shared_lab, restricted to the same traverse-only model
mkdir shared_lab/sub && chmod 710 shared_lab/sub
echo "sub data" > shared_lab/sub/data.txt && chmod 644 shared_lab/sub/data.txt

chown -R $OWNER:$GRP "$BASE"
chmod 755 "$BASE"          # let all roles reach the lab root
