"""Minimal inference API used by the Dockerfile (loads model.pkl)."""
import joblib
from fastapi import FastAPI
from pydantic import BaseModel

app = FastAPI()
model = joblib.load("model.pkl")


class Features(BaseModel):
    values: list[float]


@app.get("/health")
def health():
    return {"status": "ok"}


@app.post("/predict")
def predict(f: Features):
    return {"prediction": model.predict([f.values]).tolist()}
