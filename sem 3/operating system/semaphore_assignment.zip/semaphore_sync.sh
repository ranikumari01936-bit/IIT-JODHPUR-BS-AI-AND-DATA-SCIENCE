#!/usr/bin/env bash
# Assignment: Semaphore and Process Synchronization
# Simulates a counting semaphore initialized to 0 using a named pipe (FIFO).
set -euo pipefail

MODE="${1:-additional}"
FIFO="$(mktemp -u)"
mkfifo "$FIFO"
cleanup() {
  rm -f "$FIFO"
}
trap cleanup EXIT

p2() {
  echo "P2: Waiting for signal"
  # Reading from the FIFO blocks until P1 sends a token (signal).
  IFS= read -r token < "$FIFO"
  echo "P2: Delivery started"
  sleep 1
  echo "P2: Delivery completed"
}

p1() {
  echo "P1: Packing started"
  sleep 1
  echo "P1: Packing completed"
  # Write one token to the FIFO: signal(S).
  echo "P1: Signal sent"
  printf 'SIGNAL\n' > "$FIFO"
}

if [[ "$MODE" == "normal" ]]; then
  echo "Mode: Normal order (P1 begins first)"
  # P1 completes packing and signals; then P2 proceeds.
  p1 &
  P1_PID=$!
  p2 &
  P2_PID=$!
  wait "$P1_PID"
  wait "$P2_PID"
elif [[ "$MODE" == "additional" ]]; then
  echo "Mode: Additional task (P2 starts before P1)"
  # P2 begins first and blocks on wait(S) while the semaphore is 0.
  p2 &
  P2_PID=$!
  sleep 1
  p1 &
  P1_PID=$!
  wait "$P1_PID"
  wait "$P2_PID"
else
  echo "Usage: $0 [normal|additional]" >&2
  exit 2
fi
