#!/bin/bash
# permissions_setup.sh - Create files/directories and secure them with numeric and symbolic chmod
# Assumed requirements (none were supplied):
#   report.txt  -> 640 (rw-r-----)  owner read/write, group read, others none
#   run_backup.sh -> 755 (rwxr-xr-x) owner full, group/others read+execute
#   private_dir -> 700 (rwx------)  owner only
#   shared_dir  -> 750 (rwxr-x---)  owner full, group read+enter

WORKDIR="${1:-$HOME/permissions_lab}"
mkdir -p "$WORKDIR" && cd "$WORKDIR" || exit 1

# 1. Create files and directories
echo "Quarterly report - confidential" > report.txt
printf '#!/bin/bash\necho "backup running"\n' > run_backup.sh
mkdir -p private_dir shared_dir

# 2. Start permissive, then tighten (shows symbolic and numeric modes)
chmod 777 report.txt                 # start wide open (rwxrwxrwx)
chmod u=rw,g=r,o= report.txt         # symbolic: owner rw, group r, others none
chmod 640 report.txt                 # numeric equivalent: 6=rw-, 4=r--, 0=---  (FINAL STATE)

chmod 755 run_backup.sh              # 7=rwx, 5=r-x, 5=r-x
chmod 700 private_dir                # owner only
chmod 750 shared_dir                 # owner rwx, group r-x, others none

# 3. Verify
echo "--- ls -l ---"
ls -l report.txt run_backup.sh
ls -ld private_dir shared_dir
echo "--- numeric check ---"
stat -c '%a  %A  %n' report.txt run_backup.sh private_dir shared_dir

# 4. Non-owner write test (run as a different user, e.g. 'nobody'; needs root/sudo)
echo "--- non-owner write attempt ---"
sudo -u nobody bash -c 'echo "hacked" >> report.txt' 2>&1 \
  || setpriv --reuid=65534 --regid=65534 --clear-groups bash -c 'echo "hacked" >> report.txt'
