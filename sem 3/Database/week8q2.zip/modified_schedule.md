# Modified Schedule S2 – Recoverable and Cascadeless

> The original S2 was not supplied, so this assumes the standard non-recoverable pattern: T9 reads T8's uncommitted write on A and commits before T8.

## Original S2 (non-recoverable)

| Time | T8 | T9 |
|------|-----------|-----------|
| t1 | Read(A) | |
| t2 | Write(A) | |
| t3 | | Read(A) **← dirty read** |
| t4 | | Write(A) |
| t5 | | **Commit** |
| t6 | **Commit** (or Abort) | |

**Problems:**
- T9 reads T8's uncommitted value of A (dirty read).
- T9 commits at t5, before T8 at t6.
- If T8 fails, T9's committed work is based on data that never officially existed. A committed transaction cannot be rolled back, so the schedule is **not recoverable**.

## Corrected S2' (recoverable and cascadeless)

| Time | T8 | T9 |
|------|-----------|-----------|
| t1 | Read(A) | |
| t2 | Write(A) | |
| t3 | **Commit** | |
| t4 | | Read(A) |
| t5 | | Write(A) |
| t6 | | **Commit** |

## Changes made
1. **T8's Commit moved from t6 to t3**, immediately after its last operation and before T9 touches A.
2. **T9's Read(A) delayed from t3 to t4**, after T8's commit, so it reads only committed data.
3. **T9's Commit placed last (t6)**, so the writer commits before the reader.

## Properties
- **Recoverable:** T8 commits (t3) before T9 commits (t6).
- **Cascadeless (ACA):** T9 reads A (t4) only after T8 has committed (t3).
- **Failure of T8:** if T8 aborts before t3, T9 has not read anything yet, so no rollback of T9 is needed and there is no data loss.
- **Serial equivalent:** T8 → T9.

![Flow diagram](flow_diagram.png)
